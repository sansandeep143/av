<?php

/**
* @copyright	Copyright (C) 2012 JoomSpirit. All rights reserved.
* Slideshow based on the JQuery script Flexslider
* @license		GNU General Public License version 2 or later
*/

defined('_JEXEC') or die;


//add stylesheet

$doc =& JFactory::getDocument();


//include the class of the syndicate functions only once

require_once(dirname(__FILE__).'/helper.php');

$module_id	= $module->id;

//keeps module class suffix even if templateer tries to stop it

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));


$listofimages = mod_js_flexsliderHelper::getImages($params);

mod_js_flexsliderHelper::load_jquery($params);


$doc->addStyleSheet(JURI::base(true) . '/modules/mod_js_flexslider/assets/css/flexslider.css', 'text/css' ); 	// original Flexslider CSS
$doc->addStyleSheet(JURI::base(true) . '/modules/mod_js_flexslider/assets/css/style.css', 'text/css' );			// CSS style of JoomSpirit


$doc->addScript(JURI::base(true) . '/modules/mod_js_flexslider/assets/js/jquery.flexslider-min.js');

// Get basic parameters
$slide_theme				= $params->get('slide_theme', 'false');

$enable_minheight			= $params->get('enable_minheight');
$min_height					= $params->get('min_height');

$bg_color					= $params->get('bg_color', '#ffffff');
$theme_shadow				= $params->get('theme_shadow', 'theme-shadow-normal');
$theme_border				= $params->get('theme_border', '00');
$theme_border_radius		= $params->get('theme_border_radius', '00');

$transition					= $params->get('transition', 'fade');
$easing						= $params->get('easing', 'easeInQuart');
$direction					= $params->get('direction', 'horizontal');

$animSpeed					= intval($params->get('animSpeed', '2000'));
$pauseTime					= intval($params->get('pauseTime', '3500'));

$controlNav					= $params->get('controlNav', 'true');
$positionNav				= $params->get('positionNav', 'under');
$colorNav					= $params->get('colorNav', 'dark');
$colorNavActive				= $params->get('colorNavActive', 'black');

$directionNav				= $params->get('directionNav', 'default');

$pauseOnHover				= $params->get('pauseOnHover', 'true');
$initDelay					= $params->get('initDelay', '0');
$randomize					= $params->get('randomize', 'false');

$bg_caption					= $params->get('bg_caption', 'black');
$transparency_caption		= $params->get('transparency_caption', '2');
$position_caption			= $params->get('position_caption', 'bottom');
$text_align					= $params->get('text_align', 'centered');
$color_caption				= $params->get('color_caption', '#dddddd');


require(JModuleHelper::getLayoutPath('mod_js_flexslider'));